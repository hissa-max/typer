# typer
This website helps to extract text from photos or scanned documents and download as a word or excel document
