function checkLogin() {
  let user = localStorage.getItem("loggedInUser");
  if (!user) { window.location.href = "auth.html"; }
  return user;
}
function logout() {
  localStorage.removeItem("loggedInUser");
  window.location.href = "auth.html";
}
function saveProject(text) {
  let user = localStorage.getItem("loggedInUser");
  let projects = JSON.parse(localStorage.getItem(user + "_projects") || "[]");
  projects.push(text.slice(0, 30) + "...");
  localStorage.setItem(user + "_projects", JSON.stringify(projects));
}